package e.loanciok.simplecalculator;

public class MainActivityTest {

}