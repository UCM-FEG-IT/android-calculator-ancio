package e.loanciok.calculator;

class R {
}
